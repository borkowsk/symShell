//{{NO_DEPENDENCIES}}
// Microsoft Developer Studio generated include file.
// Used by amenager.rc
//
#define SSH_ONESTEP                     50001
#define SSH_STARTSTOP                   50002
#define SSH_FILE_DUMPSCREEN             50011
#define SSH_FILE_EXIT                   50012
#define SSH_WINDOWS_TILE_ALL            50020
#define SSH_WINDOWS_HIDEMARKEDAREAS     50021
#define SSH_WINDOWS_UNCOVERHIDDENAREAS  50022
#define SSH_WINDOWS_TILEMARKEDAREAS     50023
#define SSH_WINDOWS_RESTORETOORGINALPOSITION 50024
#define SSH_WINDOWS_MARKALLAREAS        50025
#define SSH_WINDOWS_UNMARKALLAREAS      50026
#define SSH_HELP_SHORTCUTHELP           50091
#define SSH_HELP_AUTHORSWWWPAGE         50092
#define SSH_FIRST_FREE_MESSAGE          50100

// Next default values for new objects
// 
#ifdef APSTUDIO_INVOKED
#ifndef APSTUDIO_READONLY_SYMBOLS
#define _APS_NEXT_RESOURCE_VALUE        101
#define _APS_NEXT_COMMAND_VALUE         40001
#define _APS_NEXT_CONTROL_VALUE         1000
#define _APS_NEXT_SYMED_VALUE           101
#endif
#endif
