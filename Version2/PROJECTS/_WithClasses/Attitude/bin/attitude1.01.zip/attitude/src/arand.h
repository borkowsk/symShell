//	WHICH RANDOM NUMBER GENERATOR USE THIS SIMULATION
//////////////////////////////////////////////////////
#define USES_RANDG
#include "randoms.h"
#include "wb_rand.hpp"